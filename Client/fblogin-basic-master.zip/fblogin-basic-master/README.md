fblogin-basic
=============

A code to demonstrate facebook login for websites using php sdk v4.0 with the simplest code possible

Demo : packetcode.com/apps/fblogin-basic/

Video tutorial: http://youtu.be/E8tHz5CdMrY
